class Input {
  constructor() {
    window.addEventListener('keydown', function(e){
      window.g_Input.handle_keydown(e.key);
    });
    window.addEventListener('keyup', function(e) {
      window.g_Input.handle_keyup(e.key);
    })
  }
  handle_keydown(key) {
    if(window.player){
      if (key === 'w') {
        window.player.movingup = true;
        window.player.movingdown = false;
      }
      if (key === 's') {
        window.player.movingup = false;
        window.player.movingdown = true;
      }
      if (key === 'a') {
        window.player.movingleft = true;
        window.player.movingright = false;
      }
      if (key === 'd') {
        window.player.movingleft = false;
        window.player.movingright = true;
      }
      window.player.moving = window.player.movingleft || window.player.movingright || window.player.movingdown || window.player.movingup;
    }
  }
  handle_keyup(key) {
    if(window.player){
      if (key === 'w') {
        window.player.movingup = false;
      }
      if (key === 's') {
        window.player.movingdown = false;
      }       
      if (key === 'a') {
        window.player.movingleft = false;
      }
      if (key === 'd') {
        window.player.movingright = false;
      }
      window.player.moving = window.player.movingleft || window.player.movingright || window.player.movingdown || window.player.movingup;
    }
  }
};
