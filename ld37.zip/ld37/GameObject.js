

class GameObject {
  constructor(id) {
    this.id = id;
    this.init();
  }

  init() {
    this.position = new Vector();
    this.scale =  new Vector(1,1);
    this.rotation = 0.0;
    this.tex = "textures/damnson.png";
    this.collides = true;
    this.active = true;
  }

  draw() {
    if(this.active) {
      //logic also go here
      window.g_Graphics.draw(this);
    }
  }

  update(dt) {
    if(this.active) {
      //logic go here
      this.draw();
    }
  }

  destroy() {
    //lazy meh
    window.g_Manager.destroy_object(this);
  }


}
