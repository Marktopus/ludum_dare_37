class Collider {
  constructor() {
  }

  distance(me, you) {
    let xDist = you.x - me.x;
    let yDist = you.y - me.y;
    return {
      x: xDist,
      y: yDist,
      true: Math.sqrt((xDist * xDist) + (yDist * yDist))
    }
  }
  distance_sq(me, you) {
    let xDist = you.x - me.x;
    let yDist = you.y - me.y;
    return {
      x: xDist,
      y: yDist,
      true: (xDist * xDist) + (yDist * yDist)
    }
  }

  collide_aabb_aabb(first, second) {
    var firstHalfw = first.scale.x/2;
    var secondHalfw = second.scale.x/2;
    var firstCenterx = first.position.x + firstHalfw;
    var secondCenterx = second.position.x + secondHalfw;

    var xDiff = Math.abs(firstCenterx - secondCenterx);
    var xWidths = firstHalfw + secondHalfw;
    if(xWidths < xDiff) {
      return false;
    }
    var firstHalfh = first.scale.y/2;
    var secondHalfh = second.scale.y/2;
    var firstCentery = first.position.y + firstHalfh;
    var secondCentery = second.position.y + secondHalfh;
    var yDiff = Math.abs(firstCentery - secondCentery);
    var yWidths = firstHalfh + secondHalfh;
    if(yWidths < yDiff) {
      return false;
    }
    return true;

  }

  check_collisions_with(dis) {
    var colliding = [];
    let objectList = window.g_Manager.objects;
    for(var i = 0; i < objectList.length; ++i) {
      if(dis.id != i && objectList[i].collides) {
        if(this.collide_aabb_aabb(dis, objectList[i])) {
          colliding.push(objectList[i]);
        }
      }
    }
    return colliding;
  }
}

