
class Engine {
  constructor() {
    this.active = false;
    var body = document.getElementsByTagName('body');
    body[0].style.margin = '0px';
    body[0].style.position = 'absolute';
  }

  init() {
    window.g_Input = new Input();
    window.g_Manager = new ObjectManager();
    window.g_Graphics = new Gfx();
    window.g_Collider = new Collider();
    window.g_Logic = new Logic();
    window.g_CutsceneManager = new CutsceneManager();

    window.g_CutsceneManager.init();
    this.active = true;
    g_Logic.start_game();
    window.g_Dialogue = new Dialogue();
  }

  update(dt) {
    if(!window.g_CutsceneManager.shitshappening) {
      window.g_Logic.update(dt);
    }
    window.g_Manager.update(dt);
    window.g_CutsceneManager.update(dt);
    window.g_Dialogue.update(dt);
  }
}

