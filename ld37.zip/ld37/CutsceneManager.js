class CutsceneManager {
  constructor() {
    this.cutscenes = {}
    this.cur_cutscene = null;
    this.shitshappening = false;
  }

  init() {
    this.cutscenes.throwdarock = {
      on_start: function(){
        window.player.lose_item(window.rock);
        this.duration = 0.75;
        this.totes = 0.75;
        this.rockx = window.rock.position.x;
        this.rocky = window.rock.position.y;
        this.dist = window.g_Collider.distance(window.rock.position, window.key.position);
        this.stage = 0;
      },
      on_update: function(dt){
        this.duration -= dt;
        switch(this.stage) {
          case 0:
            window.rock.position.x=this.rockx+(this.dist.x*(1-(this.duration/this.totes)));
            window.rock.position.y=this.rocky+(this.dist.y*(1-(this.duration/this.totes)));
            break;
          case 1:
            window.rock.position.x=this.rockx+(this.rockdist.x*(1-(this.duration/this.totes)));
            window.rock.position.y=this.rocky+(this.rockdist.y*(1-(this.duration/this.totes)));
            window.key.position.x=this.keyx+(this.keydist.x*(1-(this.duration/this.totes)));
            window.key.position.y=this.keyy+(this.keydist.y*(1-(this.duration/this.totes)));
            break;
        }

        if(this.duration < 0.0) {
          if(this.stage == 0) {
            this.rockx = window.rock.position.x;
            this.rocky = window.rock.position.y;
            this.keyx = window.key.position.x;
            this.keyy = window.key.position.y;
            var fuck = {
              x:window.rock.position.x,
              y:window.rock.position.y + 40
            };
            var shit = {
              x:window.key.position.x - 50,
              y:window.key.position.y + 65
            };
            this.rockdist = window.g_Collider.distance(window.rock.position, fuck);
            this.keydist = window.g_Collider.distance(window.key.position, shit);
            this.duration = 0.5;
            this.totes = 0.5;
            ++this.stage;
          } else {
            this.on_finish();
          }
        }
      },
      on_finish: function(){
        window.g_Logic.key_is_stickable = true;
        window.g_CutsceneManager.end_cutscene();
      }
    }
    this.cutscenes.stick_the_key = {
      on_start: function(){
        this.duration = 0.5;
        this.totes = 0.5;
        window.stick.position.x = window.player.position.x + window.player.scale.x/2;
        window.stick.position.y = window.player.position.y;

        this.stickx = window.stick.position.x;
        this.sticky = window.stick.position.y;
        this.stage = 0;
      },
      on_update: function(dt){
        this.duration -= dt;
        switch(this.stage) {
          case 0:
            window.stick.position.y=this.sticky-(20*(1-(this.duration/this.totes)));
            break;
          case 1:
            window.stick.position.x =
              this.stickx + (10*(1-(this.duration/this.totes)));
            break;
          case 2:
            window.stick.position.x =
              this.stickx + (-10*(1-(this.duration/this.totes)));
            break;
          case 3:
            window.stick.position.x =
              this.stickx + (10*(1-(this.duration/this.totes)));
            break;
          case 4:
            window.stick.position.x =
              this.stickx + (-10*(1-(this.duration/this.totes)));
            break;
          case 5:
            window.stick.position.y =
              this.sticky + (20*(1-(this.duration/this.totes)));
            window.key.position.y =
              this.keyy + (20*(1-(this.duration/this.totes)));
            break;
        }

        if(this.duration < 0.0) {
          switch(this.stage) {
            case 0:
              this.stickx = window.stick.position.x;
              this.sticky = window.stick.position.y;
              this.duration = 0.2;
              this.totes = 0.2;
              break;
            case 1:
              this.stickx = window.stick.position.x;
              this.duration = 0.2;
              this.totes = 0.2;
              break;
            case 2:
              this.stickx = window.stick.position.x;
              this.duration = 0.2;
              this.totes = 0.2;
              break;
            case 3:
              this.stickx = window.stick.position.x;
              this.duration = 0.2;
              this.totes = 0.2;
              break;
            case 4:
              this.sticky = window.stick.position.y;
              this.keyy = window.stick.position.y;
              this.duration = 0.5;
              this.totes = 0.5;

              break;
            default:
              this.on_finish();
          }
          ++this.stage;
        }
      },
      on_finish: function(){
        window.g_Logic.key_is_stickable = false;
        window.g_CutsceneManager.end_cutscene();
        window.player.add_item(window.key);
        window.g_Dialogue.start_dialogue(window.g_Dialogue.dudeguyobj);
      }

    }
    this.cutscenes.u_lose = {
      on_start: function(){
        this.duration = 5;
        this.totes = 5;

        this.eyesx = window.eyes.position.x;
        this.eyesy = window.eyes.position.y;
        this.stage = 0;
      },
      on_update: function(dt){
        this.duration -= dt;
        switch(this.stage) {
          case 0:
            window.eyes.position.y=this.eyesy-(20*(1-(this.duration/this.totes)));
            break;
          case 1:
            window.eyes.position.x =
              this.eyesx + (this.diffx*(1-(this.duration/this.totes)));
            window.eyes.position.y =
              this.eyesy + (this.diffy*(1-(this.duration/this.totes)));
            break;
        }

        if(this.duration < 0.0) {
          switch(this.stage) {
            case 0:
              this.eyesx = window.eyes.position.x;
              this.eyesy = window.eyes.position.y;
              this.diffx = window.player.position.x - this.eyesx;
              this.diffy = window.player.position.y - this.eyesy;
              this.duration = 1;
              this.totes = 1;
              break;
            default:
              this.on_finish();
          }
          ++this.stage;
        }
      },
      on_finish: function(){
        window.eyes.active = false;
        window.wasted.active = true;
        window.g_CutsceneManager.end_cutscene();
      }
    }
    this.cutscenes.u_win = {
      on_start: function(){
        this.duration = 5;
        this.totes = 5;

        this.playerx = window.player.position.x;
        this.playery = window.player.position.y;
        this.diffx = window.g_Logic.links[window.g_Logic.links.length - 1].position.x - window.player.position.x - window.player.scale.x - (window.dude_guy.scale.x/2);
        this.diffy = window.g_Logic.links[window.g_Logic.links.length - 1].position.y - window.player.position.y - window.player.scale.y;
        this.stage = 0;
        window.key.pickupablebool = false;
        if(window.player.has_item(window.rock)) {
          window.rock.pickupablebool = false;
        }
        window.stick.pickupablebool = false;

        window.player.lose_item(window.key);
        window.player.lose_item(window.rock);
        window.player.lose_item(window.stick);
      },
      on_update: function(dt){
        this.duration -= dt;
        switch(this.stage) {
          case 0:
            window.player.position.x=this.playerx+(this.diffx*(1-(this.duration/this.totes)));
            window.player.position.y=this.playery+(this.diffy*(1-(this.duration/this.totes)));
            window.dude_guy.position.x=window.player.position.x + window.player.scale.x;
            window.dude_guy.position.y=window.player.position.y + window.player.scale.y/2;
            break;
          case 1:
            window.player.position.x=this.playerx+(this.diffx*(1-(this.duration/this.totes)));
            window.player.position.y=this.playery+(this.diffy*(1-(this.duration/this.totes)));
            break;
          case 2:
            window.player.position.x=this.playerx+(this.diffx*(1-(this.duration/this.totes)));
            window.player.position.y=this.playery+(this.diffy*(1-(this.duration/this.totes)));
            break;
          case 3:
            window.player.position.x=this.playerx+(this.diffx*(1-(this.duration/this.totes)));
            window.player.position.y=this.playery+(this.diffy*(1-(this.duration/this.totes)));
            break;
          case 4:
            window.player.position.x=this.playerx+(this.diffx*(1-(this.duration/this.totes)));
            window.player.position.y=this.playery+(this.diffy*(1-(this.duration/this.totes)));
            break;
          case 5:
            window.player.position.x=this.playerx+(this.diffx*(1-(this.duration/this.totes)));
            window.player.position.y=this.playery+(this.diffy*(1-(this.duration/this.totes)));
            break;
        }

        if(this.duration < 0.0) {
          switch(this.stage) {
            case 0:
              this.playerx = window.player.position.x;
              this.playery = window.player.position.y;
              this.diffx = 400 - window.player.position.x;
              this.diffy = window.g_Logic.buffer.top - window.player.position.y;
              this.duration = 2;
              this.totes = 2;
              window.game_loseable = false;
              window.g_Dialogue.start_dialogue(window.g_Dialogue.dudeguyobj);
              break;
            case 1:
              window.key.position.x = 400;
              window.key.position.y = window.g_Logic.buffer.top - 50;
              this.playerx = window.player.position.x;
              this.playery = window.player.position.y;
              if(window.rock.pickupablebool) {
                this.diffx = window.rock.position.x - window.player.position.x;
                this.diffy = window.rock.position.y - window.player.position.y;
                this.duration = 1;
                this.totes = 1;
              } else {
                ++this.stage;
                this.diffx = 500 - window.player.position.x;
                this.diffy = 225 - window.player.position.y;
                this.duration = 5;
                this.totes = 5;
              }
              break;
            case 2:
              window.player.add_item(window.rock);
              this.playerx = window.player.position.x;
              this.playery = window.player.position.y;
              this.diffx = 500 - window.player.position.x;
              this.diffy = 225 - window.player.position.y;
              window.rock.pickupablebool = false;
              this.duration = 5;
              this.totes = 5;
              break;
            case 3:
              window.rock.position.x = window.player.position.x;
              window.rock.position.y = window.player.position.y;
              this.playerx = window.player.position.x;
              this.playery = window.player.position.y;
              this.diffx = 200 - window.player.position.x;
              this.diffy = 400 - window.player.position.y;
              this.duration = 5;
              this.totes = 5;
              break;
            case 4:
              window.stick.position.x = window.player.position.x;
              window.stick.position.y = window.player.position.y;
              this.playerx = window.player.position.x;
              this.playery = window.player.position.y;
              this.diffx = (window.g_Logic.buffer.right - window.player.scale.x) - window.player.position.x;
              this.diffy = window.g_Logic.buffer.top - window.player.position.y;
              this.duration = 10;
              this.totes = 10;
              break;
            default:
              this.on_finish();
          }
          ++this.stage;
        }
      },
      on_finish: function(){
        window.g_Dialogue.start_dialogue(window.g_Dialogue.dudeguyobj);
        window.g_CutsceneManager.end_cutscene();
        window.you_win = true;
      }
    }
  }

  start_cutscene(cutsceneName) {
    if(!this.shitshappening) {
      this.shitshappening = true;
      this.cur_cutscene = this.cutscenes[cutsceneName];
      this.cur_cutscene.on_start();
    }
  }

  end_cutscene() {
    this.shitshappening = false;
    this.cur_cutscene = null;
  }

  update(dt) {
    if(this.cur_cutscene) {
      this.cur_cutscene.on_update(dt);
    }
  }

}
