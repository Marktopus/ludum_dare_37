class Dialogue {
  constructor() {
    this.isDialoguing = false;
    this.curr_char = null;
    this.text_delay = 0;
    this.threshold = 0.05;
    this.idling = false;
    this.idle_time = 2;
    this.dudeguyobj = {
      tex_x: window.dude_guy.position.x - 150,
      tex_y: window.dude_guy.position.y,
      curr_line: 0,
      curr_progress: 0,
      lines: [
        "How did you get out?",
        "I... I Can't stop it",
        "...",
        "Why?..."
      ]
    };
  }

  start_dialogue (charobj) {
    this.isDialoguing = true;
    this.curr_char = charobj;
    this.curr_char.curr_progress = 0;
  }

  update(dt) {
    var self = this;
    if(self.isDialoguing) {
      if(self.text_delay >= self.threshold) {
        ++self.curr_char.curr_progress;
        self.text_delay = 0;
      }
      else if(self.idling) {
        self.idle_time -= dt;
      }
      else {
        self.text_delay += dt;
      }

      var draw_text = '';
      for(let i = 0; i < self.curr_char.curr_progress; i++) {
        draw_text += self.curr_char.lines[self.curr_char.curr_line][i];
      }

      var temp_alpha = window.g_Graphics.globalAlpha;
      window.g_Graphics.context.globalAlpha = 1;
      window.g_Graphics.context.fillStyle = '#FFFFFF';
      //window.g_Graphics.context.fillStyle = '#000000';
      window.g_Graphics.context.font = "12px sans-serif";
      window.g_Graphics.context.fillText(draw_text, self.curr_char.tex_x, self.curr_char.tex_y, 200);
      window.g_Graphics.context.globalAlpha = temp_alpha;
      if(self.curr_char.curr_progress === self.curr_char.lines[self.curr_char.curr_line].length) {
        self.idling = true;
        if(self.idle_time <= 0) {
          self.isDialoguing = false;
          self.curr_char.curr_line = Math.min(self.curr_char.curr_line + 1, self.curr_char.lines.length -1);
          self.idling = false;
          self.idle_time = 2;
        }
      }
    }
  }
}
