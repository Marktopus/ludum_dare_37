

class Vector {
  constructor(x, y) {
    this.x = x ? x : 0;
    this.y = y ? y : 0;
  }

  add(other) {
    return new Vector(this.x + other.x, this.y + other.y);
  }

  scale(scalar) {
    return new Vector(this.x * scalar, this.y * scalar);
  }
}

