class Logic {
  constructor() {
    this.num_links = 20;
    this.links = [];
    this.unchained = false;
    this.key_is_stickable = false;
    let canvasInfo = window.g_Graphics.canvas.getBoundingClientRect();
    this.buffer = {
      top: canvasInfo.top + window.g_Graphics.canvas.height*.1,
      bottom: canvasInfo.bottom - window.g_Graphics.canvas.height*.1,
      left: canvasInfo.left + window.g_Graphics.canvas.width*.01,
      right: canvasInfo.right - window.g_Graphics.canvas.width*.01
    };
  }


  start_game() {
    window.game_loseable = true;
    for(let i = 0; i < this.num_links; ++i) {
      let disLink = window.g_Manager.create_object();
      disLink.tex = new Image;
      disLink.tex.src = "textures/link.png";
      disLink.scale.x = 10;
      disLink.scale.y = 10;
      disLink.position.x = 350;
      disLink.position.y = 370;
      this.links.push(disLink);
    }
    window.light_indicator = window.g_Manager.create_object();
    window.light_indicator.scale.x = 100;
    window.light_indicator.scale.y = 100;
    window.light_indicator.position.x = -100;
    window.light_indicator.position.y = 280;
    window.light_indicator.initialy = 320;
    window.light_indicator.initialscale = 100;
    window.light_indicator.initialscalex = 100;
    window.light_indicator.tex = new Image;
    window.light_indicator.tex.src = "textures/lightonfloor.png";
    window.light_indicator.startTime = 60.0;
    window.light_indicator.timer = window.light_indicator.startTime;
    window.light_indicator.update = function(dt) {
      this.timer -= dt;

      // y = .1x^2
      this.position.x = (1 - (this.timer / this.startTime)) * (window.g_Graphics.canvas.width+500);
      if(this.position.x < window.g_Graphics.canvas.width) {

        var xFunc = this.position.x - (window.g_Graphics.canvas.width/2);
        this.position.x -=32;
        var yOffset = 0.0005 * xFunc * xFunc;
        this.position.y = this.initialy - yOffset;
        this.scale.y = this.initialscale + (80 - (yOffset));
        this.scale.x = this.initialscalex + (80/5 - (yOffset/5));
      } else {
        this.active = false;
        if(window.game_loseable) {
          window.g_Graphics.gameover = true;
        }
        // lose the fucking game.tiff
      }
      window.moon.position.x = this.position.x * -1;
      window.moon.position.x += window.g_Graphics.canvas.width - 54;
    }

    window.moon = window.g_Manager.create_object();
    window.moon.scale.x = 64;
    window.moon.scale.y = 64;
    window.moon.position.y = 32 - window.moon.scale.y/2;
    window.moon.tex = new Image;
    window.moon.tex.src = 'textures/moon.png';


    window.peephole = window.g_Manager.create_object();
    window.peephole.scale.x = 64;
    window.peephole.scale.y = 64;
    window.peephole.position.x = 320;
    window.peephole.tex = new Image;
    window.peephole.tex.src = 'textures/tothewindow.png';

    window.post = window.g_Manager.create_object();
    window.post.scale.x = 10;
    window.post.scale.y = 50;
    window.post.position.x = 347;
    window.post.position.y = 320;
    window.post.tex = new Image;
    window.post.tex.src = "textures/post.png";

    window.rock = window.g_Manager.create_object();
    window.rock.scale.x = 10;
    window.rock.scale.y = 10;
    window.rock.position.x = 500;
    window.rock.position.y = 225;
    window.rock.tex = new Image;
    window.rock.tex.src = "textures/rock.png";
    window.rock.pickupablebool = true;
    window.rock.on_pickup = function() {
      window.g_CutsceneManager.start_cutscene('throwdarock');
      window.rock.on_pickup = null;
    }

    window.key = window.g_Manager.create_object();
    window.key.scale.x = 16;
    window.key.scale.y = 16;
    window.key.position.x = 400;
    window.key.position.y = this.buffer.top-50;
    window.key.tex = new Image;
    window.key.tex.src = "textures/key.png";
    window.key.pickupablebool = true;
    window.key.on_pickup = function() {
      window.g_Logic.unchained = true;
      window.g_Logic.key_is_stickable = false;
    }

    window.stick = window.g_Manager.create_object();
    window.stick.scale.x = 15;
    window.stick.scale.y = 25;
    window.stick.position.x = 200;
    window.stick.position.y = 400;
    window.stick.tex = new Image;
    window.stick.tex.src = "textures/stick.png";
    window.stick.pickupablebool = true;

    window.dude_guy = window.g_Manager.create_object();
    window.dude_guy.scale.x = 32;
    window.dude_guy.scale.y = 32;
    window.dude_guy.position.x = this.buffer.right - window.dude_guy.scale.x;
    window.dude_guy.position.y = this.buffer.top;
    window.dude_guy.tex = new Image;
    window.dude_guy.tex.src = "textures/dude_guy_neutral.png";

    window.player = window.g_Manager.create_object();
    window.player.del_y = 0.0;
    window.player.del_x = 0.0;
    window.player.scale.x = 19;
    window.player.scale.y = 32;
    window.player.position.x = 385;
    window.player.position.y = 300;
    window.player.tex = new Image;
    window.player.speed = 1;
    window.player.tex.src = "textures/player_static.png";
    window.player.update = function(dt) {
      if(window.g_CutsceneManager.shitshappening) {
        return;
      }
      if(window.player.moving) {
        if(window.player.movingup) {
          window.player.del_y = -1;
          player.tex.src = "textures/player_up.png"
        }
        else if(window.player.movingdown) {
          window.player.del_y = 1;
          player.tex.src = "textures/player_down.png"
        } else {
          window.player.del_y= 0;
        }
        if(player.movingleft) {
          window.player.del_x = -1;
          player.tex.src = "textures/player_left.png"
        }
        else if(player.movingright) {
          window.player.del_x = 1;
          player.tex.src = "textures/player_right.png"
        } else {
          window.player.del_x = 0;
        }
        player.position.x += player.del_x * player.speed;
        player.position.y += player.del_y * player.speed;
      }
      //else if(player.tex.src !== "textures/player_static.png") {
      //  player.tex.src = "textures/player_static.png";
      //}
    };
    let player = window.player;
    player.inventory = [];
    player.sort_inventory = function() {
      let start = 50;
      let diff = 50;
      for(let i = 0; i < this.inventory.length; ++i) {
        this.inventory[i].position.y = 675;
        this.inventory[i].position.y -= (this.inventory[i].scale.y/2);
        this.inventory[i].position.x = start + i * diff;
        this.inventory[i].position.x -= this.inventory[i].scale.x/2;
      }
    }
    player.add_item = function(item) {
      if(this.has_item(item)) {
        return;
      }
      if(item.pickupablebool) {
        this.inventory.push(item);
        if(item.on_pickup) {
          item.on_pickup();
        }
        this.sort_inventory();

      }
    }
    player.has_item = function(item) {
      return this.inventory.indexOf(item) != -1;
    }
    player.lose_item = function(item) {
      let itemIndex = this.inventory.indexOf(item);
      if(itemIndex != -1) {
        this.inventory.splice(itemIndex, 1);
        this.sort_inventory();
      }
    }

    window.floor_shade = window.g_Manager.create_object();
    window.floor_shade.scale.x = 704;
    window.floor_shade.scale.y = 640;
    window.floor_shade.position.y = 64;
    window.floor_shade.tex = new Image;
    window.floor_shade.tex.src = 'textures/floorshading.png';
    window.wall_shade = window.g_Manager.create_object();
    window.wall_shade.scale.x = 704;
    window.wall_shade.scale.y = 64;
    window.wall_shade.position.y = 0;
    window.wall_shade.tex = new Image;
    window.wall_shade.tex.src = 'textures/wallshading.png';

    window.eyes = window.g_Manager.create_object();
    window.eyes.scale.x = 20;
    window.eyes.scale.y = 5;
    window.eyes.position.x = window.dude_guy.position.x;
    window.eyes.position.y = window.dude_guy.position.y;
    window.eyes.tex = new Image;
    window.eyes.tex.src = 'textures/eyes.png';
    window.eyes.active = false;

    window.wasted = window.g_Manager.create_object();
    window.wasted.scale.x = 154;
    window.wasted.scale.y = 54;
    window.wasted.position.x = (window.canvas.width/2) - (window.wasted.scale.x/2);
    window.wasted.position.y = (window.canvas.height/2) - (window.wasted.scale.y/2);
    window.wasted.tex = new Image;
    window.wasted.tex.src = 'textures/wasted.png';
    window.wasted.active = false;

  }

  chainemup() {
    let posty = {
      x: window.post.position.x + window.post.scale.x/2,
      y: window.post.position.y + window.post.scale.y,
    };
    let dudey = {
      x: window.player.position.x + window.player.scale.x/2,
      y: window.player.position.y + window.player.scale.y/2,
    };
    let distObj = window.g_Collider.distance(dudey, posty);
    let range = 240;
    if(distObj.true > range) {
      distObj.x /= distObj.true;
      distObj.y /= distObj.true;
      distObj.x *= range;
      distObj.y *= range;

      distObj.x += window.player.scale.x/2;
      distObj.y += window.player.scale.y/2;
      window.player.position.x = -distObj.x + posty.x;
      window.player.position.y = -distObj.y + posty.y;
    }
    this.movedalinks();
  }
  // i hate myself
  stepbackfromthatedgemyfriend() {
    let leftEdge = this.buffer.left;
    if(window.player.position.x < leftEdge) {
      window.player.position.x = leftEdge;
    }
    let rightEdge = (this.buffer.right - window.player.scale.x);
    if(window.player.position.x > rightEdge) {
      window.player.position.x = rightEdge;
    }
    let topEdge = this.buffer.top;
    if(window.player.position.y < topEdge) {
      window.player.position.y = topEdge;
    }
    let bottomEdge = (this.buffer.bottom - window.player.scale.y);
    if(window.player.position.y > bottomEdge) {
      window.player.position.y = bottomEdge;
    }
  }

  pickupshit() {
    let importantcollisions = [];
    let collisions = window.g_Collider.check_collisions_with(window.player);
    for(let i = 0; i < collisions.length; ++i) {
      if(collisions[i].pickupablebool) {
        window.player.add_item(collisions[i]);
      } else {
        importantcollisions.push(collisions[i]);
      }
    }
    window.player.collisions = importantcollisions;
  }

  movedalinks() {
    let maxLinkDist = 5;
    let maxLinkDistSq = 25;
    this.links[0].position.x = window.post.position.x + window.post.scale.x/2;
    this.links[0].position.y = window.post.position.y + window.post.scale.y;

    this.links[this.links.length - 1].position.x = window.player.position.x + window.player.scale.x/2;
    this.links[this.links.length - 1].position.y = window.player.position.y + window.player.scale.y/2;

    for(let i = this.links.length -2; i >= 1; --i) {
      let frontdist = window.g_Collider.distance_sq(this.links[i + 1].position, this.links[i].position);
      if(frontdist.true > maxLinkDistSq){
        let lenf = Math.sqrt(frontdist.true);
        frontdist.x/=lenf;
        frontdist.y/=lenf;
        frontdist.x*=maxLinkDist;
        frontdist.y*=maxLinkDist;
        let workingX = this.links[i + 1].position.x + frontdist.x;
        let workingY = this.links[i + 1].position.y + frontdist.y;
        let backdist = window.g_Collider.distance_sq(this.links[i - 1].position, {x: workingX, y: workingY});
        if(backdist.true > maxLinkDistSq) {
          let lenb = Math.sqrt(backdist.true);
          backdist.x/=lenb;
          backdist.y/=lenb;
          backdist.x*=maxLinkDist;
          backdist.y*=maxLinkDist;
          this.links[i].position.x = this.links[i - 1].position.x + backdist.x;
          this.links[i].position.y = this.links[i - 1].position.y + backdist.y;
          let distToFront = window.g_Collider.distance_sq(this.links[i + 1].position, this.links[i].position);
          if(distToFront.true > maxLinkDistSq) {
            this.links[i].position.x = (this.links[i+1].position.x - this.links[i-1].position.x) / 2;
            this.links[i].position.y = (this.links[i+1].position.y - this.links[i-1].position.y) / 2;
            this.links[i].position.x += (this.links[i-1].position.x);
            this.links[i].position.y += (this.links[i-1].position.y);
          }

        }
      }
    }
  }

  update(dt) {
    this.pickupshit();
    this.stepbackfromthatedgemyfriend();
    if(!this.unchained) {
      this.chainemup();
    }

    if(window.player.has_item(window.stick) && this.key_is_stickable) {
      //if we close enough to da key
      var distObj = window.g_Collider.distance(window.player.position, window.key.position);
      if(distObj.true < 30) {
        window.g_CutsceneManager.start_cutscene('stick_the_key');
        //stick the key
        //cutscene
      }
    }

    if(!window.endgame && window.player.collisions.indexOf(window.dude_guy) != -1) {
      // u win
      window.endgame = true;
      window.g_CutsceneManager.start_cutscene('u_win');
      window.g_Dialogue.start_dialogue(window.g_Dialogue.dudeguyobj);

    }

  }
}
