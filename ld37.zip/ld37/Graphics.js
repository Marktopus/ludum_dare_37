
class Gfx {
  constructor() {
    this.canvas = document.getElementById('canvas');
    this.canvas.width = 704;
    this.canvas.height = 704;
    this.context = this.canvas.getContext('2d');
    this.wall = new Image;
    this.wall.src = 'textures/wall.png';
    this.floor = new Image;
    this.floor.src = 'textures/floor.png';
    this.gameover = false;
  }

  init() {
  }
  begin_scene() {
    this.context.beginPath();
    this.context.clearRect(0,0, this.canvas.width, this.canvas.height);
    if(this.gameover || window.you_win) {
      if(this.context.globalAlpha > 0) {
        this.context.globalAlpha -= 0.0005;
        if(this.context.globalAlpha < 0.0005) {
          this.context.globalAlpha = 0;
          if(!window.you_win) {
            window.eyes.active = true;
            window.g_CutsceneManager.start_cutscene('u_lose');
          }
        }
      }
    }
  }
  draw() {
    this.begin_scene();
    this.draw_floor();
    for(var i = 0; i < window.g_Manager.objects.length; ++i) {
      if(window.g_Manager.objects[i].active) {
        if(window.g_Manager.objects[i].id != (5 + window.g_Logic.num_links)) {
          if(window.g_Manager.objects[i].id != (4 + window.g_Logic.num_links)) {
            if(window.g_Manager.objects[i].id < (9 + window.g_Logic.num_links)) {
              this.draw_one(window.g_Manager.objects[i]);
            }
          }
        }
      }
    }
    this.draw_wall();
    this.draw_one(window.key);
    this.draw_one(window.rock);
    this.draw_one(window.floor_shade);
    this.draw_one(window.wall_shade);
    //  HACK HACK HACK
    if(!window.you_win && this.context.globalAlpha == 0) {
      this.context.globalAlpha = 1;
      if(window.eyes.active) {
        this.draw_one(window.eyes);
      }
      if(window.wasted.active) {
        this.draw_one(window.wasted);
      }
      this.context.globalAlpha = 0;
    }
    this.end_scene();
  }

  end_scene() {
    this.context.closePath();
  }

  draw_one(object) {
    //background shit
    //this.context.fillStyle = this.context.createPattern(object.tex, 'no-repeat');
    //this.context.rotate(object.rotation);
    this.context.drawImage( object.tex, object.position.x, object.position.y,
                            object.scale.x, object.scale.y);
    //this.context.rotate(-object.rotation);
  }

  update(dt) {
    this.draw_wall();
    this.draw_floor();
  }

  draw_wall() {
    this.context.fillStyle = this.context.createPattern(this.wall, 'repeat-x');
    this.context.fillRect(0,0,320, 64);
    this.context.fillRect(384,0,384, 64);
  }
  draw_floor() {
    this.context.fillStyle = this.context.createPattern(this.floor, 'repeat');
    this.context.fillRect(0,64,704, 704-128);
  }
};

