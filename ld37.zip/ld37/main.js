function main() {
  console.log('hey')
  window.g_Engine = new Engine();
  window.g_Engine.init();
  var updater = function() {
    window.g_Engine.update(1.0/60.0);
    if(window.g_Engine.active){
      requestAnimationFrame(updater);
    }
  } 
  updater();
}

(function(){
  main();
})();
